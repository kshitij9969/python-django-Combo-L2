#include <Python.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <vector>

using namespace std;
struct employee{
    string fname;
    string sname;
    string deptname;
    int basic_salary;
    string designation;
    string dob;
    string employee_type;
};

static PyObject *method_add(PyObject *self, PyObject *args) {
    string fname = NULL;
    string sname = NULL;
    string deptname = NULL;
    int basic_salary = 0;
    string designation = NULL;
    string dob = NULL;
    string employee_type = NULL;

    /* Parse arguments */
    if(!PyArg_ParseTuple(args, "sssisss", fname, sname, deptname, basic_salary, designation, dob, employee_type)) {
        return NULL;
    }

   std::vector<employee> employees;
   struct employee emp = {fname, sname, deptname, basic_salary, designation, dob, employee_type};
   int init_size = employees::size();
   employees.push_back(emp);
   if(employees::size() == init_size + 1) {
        return PyLongObject(1);
   }
   else {
        return NULL;
   }
}

// here I will put all the methods I define
static PyMethodDef empmethods[] = {
    {"add", method_add, METH_VARARGS, "Adds a new employee to the database"},
    {NULL, NULL, 0, NULL}
};


static struct PyModuleDef employee_module = {
    PyModuleDef_HEAD_INIT,
    "employee_database",
    "Contains methods to add, remove, get employee details",
    -1,
    empmethods
};

PyMODINIT_FUNC PyInit_employee_module(void) {
    return PyModule_Create(&employee_module);
}