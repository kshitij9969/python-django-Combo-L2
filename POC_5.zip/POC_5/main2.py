#!/usr/bin/python
import fputs

print(main.helloworld())