class string_comparision():
    def __init__(self, string):
        self.string = string

    def __gt__(self, other):
        if len(self.string) > len(other.string):
            return self.string
        else:
            return other.string


string1 = string_comparision('Hello')
string2 = string_comparision('Hello1')
print("The longer string is: " + (string1 > string2))

