class matrix():
    def __init__(self, first, second, third, fourth):
        self.first = first
        self.second = second
        self.third = third
        self.fourth = fourth

    def __add__(self, other):
        first = self.first + other.first
        second = self.second + other.second
        third = self.third + other.third
        fourth = self.fourth + other.fourth
        result = matrix(first, second, third, fourth)
        return result

    def __str__(self):
        return f"{self.first} {self.second} {self.third} {self.fourth}"


first_matrix = matrix(1, 2, 3, 4)
second_matrix = matrix(1, 2, 3, 4)

print(first_matrix + second_matrix)


