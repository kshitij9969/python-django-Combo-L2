class sqroot():
    def sqroot_fun(self, num):
        try:
            return num ** 0.5
        except ArithmeticError:
            return 'Arithmetic error'


class addition():
    def add_fun(self, num1, num2):
        return num1 + num2


class subtraction():
    def sub_fun(self, num1, num2):
        return num2 - num1


class division():
    def division_fun(self, num1, num2):
        try:
            return num1 / num2
        except ZeroDivisionError:
            return 'Zero division error'


class multiplication():
    def mul_fun(self, num1, num2):
        return num1 * num2



class mathnew(sqroot, addition, subtraction, multiplication, division):
    def sqroot_fun(self, num1):
        return super().sqroot_fun(num1)

    def add_fun(self, num1, num2):
        return super().add_fun(num1, num2)

    def sub_fun(self, num1, num2):
        return super().sub_fun(num1, num2)

    def mul_fun(self, num1, num2):
        return super().mul_fun(num1, num2)

    def division_fun(self, num1, num2):
        return super().division_fun(num1, num2)


obj = mathnew()
print(obj.sqroot_fun(10))
print(obj.sqroot_fun(-10))
print(obj.add_fun(10, 20))
print(obj.sub_fun(20, 10))
print(obj.mul_fun(10, 20))
print(obj.division_fun(20, 10))
print(obj.division_fun(10, 0))
class sqroot():
    def sqroot_fun(self, num):
        try:
            return num ** 0.5
        except ArithmeticError:
            return 'Arithmetic error'


class addition():
    def add_fun(self, num1, num2):
        return num1 + num2


class subtraction():
    def sub_fun(self, num1, num2):
        return num2 - num1


class division():
    def division_fun(self, num1, num2):
        try:
            return num1 / num2
        except ZeroDivisionError:
            return 'Zero division error'


class multiplication():
    def mul_fun(self, num1, num2):
        return num1 * num2



class mathnew(sqroot, addition, subtraction, multiplication, division):
    def sqroot_fun(self, num1):
        return super().sqroot_fun(num1)

    def add_fun(self, num1, num2):
        return super().add_fun(num1, num2)

    def sub_fun(self, num1, num2):
        return super().sub_fun(num1, num2)

    def mul_fun(self, num1, num2):
        return super().mul_fun(num1, num2)

    def division_fun(self, num1, num2):
        return super().division_fun(num1, num2)


obj = mathnew()
print(obj.sqroot_fun(10))
print(obj.sqroot_fun(-10))
print(obj.add_fun(10, 20))
print(obj.sub_fun(20, 10))
print(obj.mul_fun(10, 20))
print(obj.division_fun(20, 10))
print(obj.division_fun(10, 0))
