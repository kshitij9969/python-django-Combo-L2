def sqroot(num):
    return num ** 0.5


def addition(num1, num2):
    return num1 + num2


def subtraction(num1, num2):
    return num2 - num1


def multiplication(num1, num2):
    return num1 * num2


def division(num1, num2):
    return num1 / num2
