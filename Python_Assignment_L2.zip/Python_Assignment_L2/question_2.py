import re

email = 'From abc.xyz@pqr.com Mon Dec 29 01:12:15 2016'

email_id = re.findall('[a-zA-Z0-9\.\_]+@[a-zA-Z0-9\.\_]+', email)
print('email ID is ' + email_id[0].split('@')[0])

print('domain is ' + email_id[0].split('@')[1])

time = re.findall('[0-9]{2,2}:[0-9]{2,2}:[0-9]{2,2}\s[0-9]{4,4}', email)

print(time)