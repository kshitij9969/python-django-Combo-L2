# First when the object of Fourth class calls method1, if it is present in the local scope of the class it is executed, else it uses
# depth first left to right. Which means it will go to Two and eventually One down the heirarchy, if not match is found, it will move
# to Third class and then to First, if not found it will look into the Global Scope and then in the Built-in scope to find the method, and
# would eventually return method not found error if not match is found.

class First():
    def __init__(self):
        pass

    def method1(self):
        return 'In first'


class Second(First):
    def __init__(self):
        pass

    def method1(self):
        return 'In second'


class Third(First):
    def __init__(self):
        pass

    def method1(self):
        return 'In third'


class Fourth(Second, Third):
    def __init__(self):
        pass

    def method1(self):
        return 'In fourth'

