class Mymath:

    def __init__(self):
        pass

    @staticmethod
    def sqroot(num):
        return num ** 0.5

    @staticmethod
    def addition(num1, num2):
        return num1 + num2

    @staticmethod
    def subtraction(num1, num2):
        return num2 - num1

    @staticmethod
    def multiplication(num1, num2):
        return num1 * num2

    @staticmethod
    def division(num1, num2):
        try:
            return num1 / num2
        except ZeroDivisionError:
            return 'Can\'t divide by zero.'


print(Mymath.sqroot(5))
print(Mymath.addition(5, 6))
print(Mymath.subtraction(5, 4))
print(Mymath.multiplication(5, 6))
print(Mymath.division(5, 6))
print(Mymath.division(5, 0))
