class Circle():
    def area(self, radius):
        return 3.14 * radius ** 2

    def circumference(self, radius):
        return 2 * 3.14 * radius


circle = Circle()
print("Area = " + str(circle.area(10)))
print("Circumference = " + str(round(circle.circumference(10), 2)))
