import xml.etree.ElementTree as ET

tree = ET.parse('file.xml')
root = tree.getroot()

for book in root:
    print(book.tag)
    for information in book:
        print(information.tag + ' ' + information.text)


