
list1 = [i for i in range(10)]
list1 = list1 * 2

list2 = []
for i in list1:
    if i not in list2:
        list2.extend([i])


print(list2)
