string1 = input('Enter the string: ')

print(True) if list(string1).count('e') == 2 else print(False)

