# First print will output None
# Second print will output 7