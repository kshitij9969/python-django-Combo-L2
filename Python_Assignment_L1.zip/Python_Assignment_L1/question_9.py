import os

files = os.listdir('./')

for file in files:
    if os.stat(file).st_size == 0:
        print(file)