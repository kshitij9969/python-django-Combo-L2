"""

It is a generator, it will iterate over range(n) and yield cubes of each value.

Output:
1
8
27
64
125
216

"""