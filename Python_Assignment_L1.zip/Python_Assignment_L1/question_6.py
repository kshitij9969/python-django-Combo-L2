list1 = [1, 2, 3, 4]
list2 = [5, 6, 7, 8]
list3 = [9, 10, 11, 12]

maxlist = []

maxlist.extend([max(list1), max(sorted(list1)[:-1]),
                max(list2), max(sorted(list2)[:-1]),
                max(list3), max(sorted(list3)[:-1])])

max_avg = sum(i for i in maxlist)/len(maxlist)

minlist = []

minlist.extend([min(list1), min(sorted(list1, reverse=True)[:-1]),
                min(list2), min(sorted(list2, reverse=True)[:-1]),
                min(list3), min(sorted(list3, reverse=True)[:-1])])

min_avg = sum(i for i in minlist)/len(minlist)
