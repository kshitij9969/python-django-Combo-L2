with open('input.txt', 'r+') as file_obj, open('output.txt', 'w') as output_file:
    line_count = 1
    for line in file_obj.readlines():
        output_file.write('words on line ' + str(line_count) + ' ' + str(len(str(line).split(' '))) + '\n')
        output_file.write('characters on line ' + str(line_count) + ' ' + str(len((line))) + '\n')
        line_count += 1


