'''

mylist will hold reference to range object and so will seclist.

First print(seclist) will output range(0, 4)

mylist.append(4) will throw an error because range object doesn't have any append method

if we escape that, seclist will still hold reference to range(0, 4)

Again, mylist.append(5) will throw an error and seclist will remain unchanged

'''